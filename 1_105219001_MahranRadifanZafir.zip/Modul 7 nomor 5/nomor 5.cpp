#include <iostream>
using namespace std;

int main()
{
    string daftarNama[100], nama;
    string daftarNomorTelepon[100], nomorTelepon;
    cout<<"nama: ";cin>>nama;
    cout<<"nomor telepon: ";cin>>nomorTelepon;
    int indeks=0, data=0;
    while(data<100 && (nama!="done" && nomorTelepon!="done")){
        daftarNama[data]=nama; daftarNomorTelepon[data]=nomorTelepon;
        cout<<"nama: ";cin>>nama;
        cout<<"nomor telepon: ";cin>>nomorTelepon;
        data++;
    }
    string cariNomor; bool terdeteksi=false;
    cout<<"mencari nomor atas nama: ";cin>>cariNomor;
    while(indeks<data){
        if(daftarNama[indeks]==cariNomor){
            cout<<daftarNomorTelepon[indeks];
             /*tambahan nomor 5.c*/terdeteksi=true;
        }
        indeks++;
    }
     /*tambahan nomor 5.c*/if(terdeteksi==false){
        cout<<"nama yang anda cari tidak ada di dalam daftar";
    }

    return 0;
}
